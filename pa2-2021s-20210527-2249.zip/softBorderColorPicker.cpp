#include "softBorderColorPicker.h"

SoftBorderColorPicker::SoftBorderColorPicker(unsigned int width, PNG& inputimage, double tol)
{
    /* your code here */
}

HSLAPixel SoftBorderColorPicker::operator()(point p)
{
    /* your code here */
}
