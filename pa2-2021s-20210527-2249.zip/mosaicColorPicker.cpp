#include "mosaicColorPicker.h"

MosaicColorPicker::MosaicColorPicker(int mosaicwidth, PNG& inputimage)
{
  /* your code here */
}

HSLAPixel MosaicColorPicker::operator()(point p)
{
  /* your code here */
}
